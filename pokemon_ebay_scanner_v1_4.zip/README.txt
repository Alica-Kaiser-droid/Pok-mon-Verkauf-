Pokémon eBay Scanner V1.4

Eindeutiger Build-Stempel:
2026-08-21-01

Diese Version dient zuerst zur sicheren Prüfung, dass GitHub Pages
wirklich die neue index.html ausliefert.
